
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "packet32.h"
#include "ntddndis.h"

#define Max_Num_Adapter 10


void PrintPackets(LPPACKET lpPacket);
char AdapterList[Max_Num_Adapter][1024];


int main()
{
    LPADAPTER   lpAdapter = 0;
    LPPACKET    lpPacket;
    int         i;
    DWORD       dwErrorCode;
    char		AdapterName[8192];
    char		*temp,*temp1;

    int			AdapterNum=0,Open;
    ULONG		AdapterLength;
    char        buffer[256000];
    struct      bpf_stat stat;
    float	cpu_time;

    char packetbuff[]={
        0x00, 0x1e, 0x2a, 0x1f, 0x4e, 0x8c, 0x00, 0xa0,
        0xd1, 0xc1, 0x0d, 0xb8, 0x08, 0x00, 0x45, 0x00,
        0x00, 0x30, 0x86, 0xb9, 0x40, 0x00, 0x80, 0x06,
        0x96, 0xed, 0xc0, 0xa8, 0x00, 0x02, 0x95, 0xae,
        0x86, 0xc8, 0x07, 0xc3, 0x00, 0x50, 0xe5, 0x5d,
        0x07, 0x87, 0x00, 0x00, 0x00, 0x00, 0x70, 0x02,
        0xff, 0xff, 0xb1, 0x06, 0x00, 0x00, 0x02, 0x04,
        0x05, 0xb4, 0x01, 0x01, 0x04, 0x02
    };

    printf("Packet.dll test application. Library version:%s\n", PacketGetVersion());
    printf("Adapters installed:\n");
    i=0;

    AdapterLength = sizeof(AdapterName);

    if(PacketGetAdapterNames(AdapterName,&AdapterLength)==FALSE){
        printf("Unable to retrieve the list of the adapters!\n");
        return -1;
    }
    temp=AdapterName;
    temp1=AdapterName;

    while ((*temp!='\0')||(*(temp-1)!='\0'))
    {
        if (*temp=='\0')
        {
            memcpy(AdapterList[i],temp1,temp-temp1);
            temp1=temp+1;
            i++;
        }
        temp++;
    }

    AdapterNum=i;
    for (i=0;i<AdapterNum;i++)
        printf("\n%d- %s\n",i+1,AdapterList[i]);
    printf("\n");

    do {
        printf("Select the number of the adapter to open : ");
        scanf("%d",&Open);
        if (Open>AdapterNum) printf("\nThe number must be smaller than %d",AdapterNum);
    } while (Open>AdapterNum);

    lpAdapter = PacketOpenAdapter(AdapterList[Open-1]);

    if (!lpAdapter || (lpAdapter->hFile == INVALID_HANDLE_VALUE))
    {
        dwErrorCode=GetLastError();
        printf("Unable to open the adapter, Error Code : %lx\n",dwErrorCode);

        return -1;
    }

	if((lpPacket = PacketAllocatePacket())==NULL){
		printf("\nError:failed to allocate the LPPACKET structure.");
		return (-1);
	}

	PacketInitPacket(lpPacket,packetbuff,sizeof(packetbuff));

	if(PacketSetNumWrites(lpAdapter,10000)==FALSE){
		printf("warning: Unable to send more than one packet in a single write!\n");
	}

	printf("\n\nGenerating %d packets...",10000);

	cpu_time = (float)clock ();

	if(PacketSendPacket(lpAdapter,lpPacket,TRUE)==FALSE){
		printf("Error sending the packets!\n");
		return -1;
	}

	cpu_time = (clock() - cpu_time)/CLK_TCK;

	printf ("\n\nElapsed time: %5.3f\n", cpu_time);

	PacketFreePacket(lpPacket);
	PacketCloseAdapter(lpAdapter);
	return (0);
}
